Logiciel ©StopCovid iOS ci-après dénommé "le Logiciel"  
Société ©LUNABEE STUDIO, ci-après dénommée "la Société"  
©2020

Compte tenu des enjeux et des impacts du projet, ainsi que des technologies qui sont mises en œuvre, l’accès au code source à des fins de vérification et de transparence sur les algorithmes et les logiciels utilisés est une nécessité. La présente licence y répond, en complément de la publication open source de certaines parties critiques des programmes développés.

Le Logiciel a été conçu et réalisé par les développeurs de la Société.

La société détient tous les droits de propriété sur le Logiciel.

Le Logiciel est en cours de développement et la Société souhaite qu'il soit utilisé de façon à en prendre connaissance, à l'évaluer et à en tester les performances et fonctionnalités.

A cette fin la Société a décidé de distribuer le Logiciel sous forme d'une archive du code source, produite à intervales réguliers, et mise à disposition sur le présent serveur gitlab du projet.

La Société concède gratuitement à l'utilisateur, pour une période de un (1) an à compter du téléchargement du code, le droit non exclusif, sans droit de sous licence, d'utiliser le Logiciel aux seules fins de test et/ou d’en permettre son évaluation scientifique.

Le licencié peut résilier la période d'évaluation avant son expiration à tout moment en détruisant toutes les copies du logiciel ou en les renvoyant à la Société. Tout droit d'utiliser le logiciel prend fin automatiquement lorsque (a) le Licencié ne respecte pas les termes de la présente licence et (b) à l'expiration de la période d'évaluation.

Tout utilisateur du Logiciel pourra communiquer ses remarques d'utilisation du Logiciel à l'équipe de développement du Logiciel à travers l'interface de gitlab.

La présente licence d'évaluation n'entraîne aucun droit pour l'utilisateur à recevoir une assistance quelconque de la part de la Société au cours de la période d'évaluation.

L'UTILISATEUR NE PEUT FAIRE AUCUNE AUTRE UTILISATION QUE CELLE DEFINIE CI-AVANT.
L'UTILISATEUR NE PEUT FAIRE NI EXPLOITATION NI DISTRIBUTION EN L'ETAT OU AVEC DES MODIFICATIONS (COMMERCIALE OU GRACIEUSE). TOUTE UTILISATION DU LOGICIEL DANS LE CADRE D'UN ENVIRONNEMENT DE PRODUCTION EST EXCLUE. TOUT ACTE CONTRAIRE CONSTITUERAIT LE DÉLIT DE CONTREFAÇON.

LE LOGICIEL EST FOURNI "TEL QU'EN L'ÉTAT" SANS AUCUNE GARANTIE DE QUELQUE NATURE, IMPLICITE OU EXPLICITE, QUANT À SON UTILISATION COMMERCIALE, PROFESSIONNELLE, LÉGALE OU NON, OU AUTRE, SES PERFORMANCES, SA COMMERCIALISATION OU SON ADAPTATION A UN USAGE SPECIFIQUE.
AU COURS DE LA PHASE D'ÉVALUATION, LE CLIENT UTILISE LE LOGICIEL À SES PROPRES RISQUES, CHARGE ET RESPONSABILITÉ.

SAUF LORSQU'EXPLICITEMENT PRÉVU PAR LA LOI, LA SOCIETE NE POURRA ÊTRE TENU POUR RESPONSABLE DE TOUT DOMMAGE OU PRÉJUDICE DIRECT,INDIRECT, SECONDAIRE OU ACCESSOIRE (PERTES FINANCIÈRES DUES AU MANQUE À GAGNER, À L'INTERRUPTION D'ACTIVITÉS OU À LA PERTE DE DONNÉES, ETC...) DÉCOULANT DE L'UTILISATION DE TOUT OU PARTIE DU LOGICIEL OU DE L'IMPOSSIBILITÉ D'UTILISER CELUI-CI.
