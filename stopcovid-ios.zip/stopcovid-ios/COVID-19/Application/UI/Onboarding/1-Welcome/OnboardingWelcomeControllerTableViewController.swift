//
//  OnboardingWelcomeController.swift
//  COVID-19
//
//  Created by Nicolas on 08/04/2020.
//  Copyright © 2020 Lunabee Studio. All rights reserved.
//

import UIKit

final class OnboardingWelcomeController: UITableViewController {

    override func viewDidLoad() {
        super.viewDidLoad()
    }

}
