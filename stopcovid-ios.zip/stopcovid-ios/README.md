**Note** : La publication de l'intégralité du code source de l’application mobile sous iOS fait apparaitre des écrans et des textes.
Ces écrans et ces textes vont évoluer au cours des jours qui viennent, en amont de tout déploiement éventuel, du fait :

- de la prise en compte des éléments recommandés dans les délibérations de la CNIL,
- des retours des tests,
- de la prise en compte de l'ensemble des exigences en matière d'accessibilité,
- de la précision des éléments légaux, de tout autre élément susceptible de conduire à des modifications.

# StopCovid iOS

Ce projet gitlab.inria.fr est un des composants de la solution plus globale [StopCovid](https://gitlab.inria.fr/stopcovid19/accueil/-/blob/master/README.md).

Ce composant est le code de l'application mobile sous iOS.
